<script setup></script>

<template>
	<div id="about-me">
		<h2>63130500042</h2>
		<h2>Songglod Petchamras</h2>
		<p>Server-side</p>
	</div>
</template>

<style scoped></style>
